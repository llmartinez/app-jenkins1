<?php
namespace Adservice\CarBundle\Tests\Entity;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class CarControllerTest extends WebTestCase {

    public function testIsTrue(){
        $this->assertTrue(true);
        $this->assertFalse(false);
    }

}
