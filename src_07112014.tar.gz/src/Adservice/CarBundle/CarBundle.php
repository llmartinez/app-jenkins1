<?php

namespace Adservice\CarBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CarBundle extends Bundle
{
}
