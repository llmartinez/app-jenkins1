<?php

namespace Adservice\PartnerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartnerBundle extends Bundle
{
}
