<?php

namespace Adservice\ImportBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ImportBundle extends Bundle
{
}
