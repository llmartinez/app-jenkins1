<?php

namespace Adservice\WorkshopBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WorkshopBundle extends Bundle
{
}
