<?php

namespace Adservice\OrderBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class WorkshopOrderControllerTest extends WebTestCase
{
    public function testIsTrue(){
        $this->assertTrue(true);
        $this->assertFalse(false);
    }
}
