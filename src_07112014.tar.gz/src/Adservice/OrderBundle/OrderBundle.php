<?php

namespace Adservice\OrderBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrderBundle extends Bundle
{
}
