<?php

namespace Adservice\StatisticBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class StatisticControllerTest extends WebTestCase {

    public function testIsTrue(){
        $this->assertTrue(true);
        $this->assertFalse(false);
    }

}