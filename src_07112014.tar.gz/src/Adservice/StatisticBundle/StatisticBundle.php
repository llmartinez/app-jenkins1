<?php

namespace Adservice\StatisticBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StatisticBundle extends Bundle
{
}
