<?php

namespace Adservice\PopupBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PopupBundle extends Bundle
{
}
