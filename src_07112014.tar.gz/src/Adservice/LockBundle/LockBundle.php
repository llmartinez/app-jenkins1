<?php

namespace Adservice\LockBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LockBundle extends Bundle
{
}
