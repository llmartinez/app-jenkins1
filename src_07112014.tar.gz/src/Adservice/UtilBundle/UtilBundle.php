<?php

namespace Adservice\UtilBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UtilBundle extends Bundle
{
}
