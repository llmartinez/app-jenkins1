<?php
namespace Adservice\UtilBundle\Tests\Entity;

use Adservice\UtilBundle\Entity\Region;

class RegionTest extends \PHPUnit_Framework_TestCase
{
   protected $region;

   public function testSettersRegion()
   {
       $region = new Region();
       $region->setRegion('RegionTest');

       $this->region = $region;
   }

   public function testGettersRegion()
   {
       $region = $this->region;
       return $region;
   }

   public static function GetRegion()
   {
       $region = new Region();
       $region->setRegion('RegionTest');

       return $region;
   }
}
