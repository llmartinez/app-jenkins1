<?php

namespace Adservice\TicketBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TicketBundle extends Bundle
{
}
